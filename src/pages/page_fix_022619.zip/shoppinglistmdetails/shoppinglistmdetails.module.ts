import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ShoppinglistmdetailsPage } from './shoppinglistmdetails';

@NgModule({
  declarations: [
    ShoppinglistmdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ShoppinglistmdetailsPage),
  ],
})
export class ShoppinglistmdetailsPageModule {}
