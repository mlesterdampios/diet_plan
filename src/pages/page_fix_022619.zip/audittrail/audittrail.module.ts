import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AudittrailPage } from './audittrail';

@NgModule({
  declarations: [
    AudittrailPage,
  ],
  imports: [
    IonicPageModule.forChild(AudittrailPage),
  ],
})
export class AudittrailPageModule {}
