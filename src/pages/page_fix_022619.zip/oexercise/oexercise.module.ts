import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { oExercisePage } from './oexercise';

@NgModule({
  declarations: [
    oExercisePage,
  ],
  imports: [
    IonicPageModule.forChild(oExercisePage),
  ],
})
export class oExercisePageModule {}
