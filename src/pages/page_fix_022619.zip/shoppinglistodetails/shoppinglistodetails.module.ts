import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ShoppinglistodetailsPage } from './shoppinglistodetails';

@NgModule({
  declarations: [
    ShoppinglistodetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ShoppinglistodetailsPage),
  ],
})
export class ShoppinglistodetailsPageModule {}
